These files are only for Microsoft's built-in
Routing and Remote Access Service (RRAS) as a
VPN gateway using IKEv2, L2TP, SSTP or PPTP.
