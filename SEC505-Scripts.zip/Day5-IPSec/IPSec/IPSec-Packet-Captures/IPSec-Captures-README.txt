WireShark correctly parses the IKE captures, but not the AuthIP captures.


To parse the AuthIP captures, do two things:


1) Install Microsoft Network Monitor 3.4 or later:

	http://blogs.technet.com/b/netmon/p/downloads.aspx		
	http://blogs.technet.com/b/netmon/


2) In Network Monitor, pull down the Tools menu > Options > 
   Parser Profiles tab > set the "Windows" profile as active.








Optional: Get the latest Network Monitor parsers from CodePlex:

	http://nmparsers.codeplex.com





