Not required, but .PSD1 data files could be placed in this folder
to make it easier to reuse a set of build scripts with different
machines with different sets of configuration settings.  In general,
machine-specific settings could/should be separated from the
build scripts and placed into one or more .PSD1 data files.
