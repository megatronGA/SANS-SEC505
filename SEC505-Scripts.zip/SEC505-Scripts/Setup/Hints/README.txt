These are hint files for the final lab on Day 6.
