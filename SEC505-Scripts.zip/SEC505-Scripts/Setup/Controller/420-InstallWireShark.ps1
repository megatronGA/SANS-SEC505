###############################################################################
#
#"[+] Installing Wireshark..."  
#
# Confirm that this is still in .\Tools\WireShark
# This takes too long...
# 
###############################################################################
# $setup = dir .\Resources\WireShark\*wireshark*.exe | select -last 1
# invoke-expression -command ($setup.FullName + " /S /desktopicon=yes /quicklaunch=no")
# Start-Sleep -Seconds 20

