DSC stands for "Desired State Configuration."

SEC505 used to have a long module on DSC, but I deleted
it all in 2018 after Microsoft made announcements which
made the future of DSC uncertain.  The scripts for the
DSC labs are all still here though, just be aware that
on-premises DSC has a 50% chance of survival at best,
hence, you are perhaps better off investing your
time in products like Puppet or Chef instead, if you
are looking for a DevOps product similar to DSC.
